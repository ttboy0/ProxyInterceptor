/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this file,
 * You can obtain one at http://mozilla.org/MPL/2.0/. */

const {classes: Cc, interfaces: Ci, utils: Cu} = Components;

Cu.import("resource://gre/modules/AddonManager.jsm");
Cu.import("resource://gre/modules/Services.jsm");
Cu.import("resource://gre/modules/osfile.jsm");

const APP_UPDATE_URL_PREF = "app.update.url";
const REPLACE_KEY = "%OS_VERSION%";

function install(data, reason) {
  if (!shouldHotfixApp()) {
    uninstallHotfix(data);
    return;
  }

  AddonManager.getAddonByID(data.id, function(addon) {
    // Enable on install in case the user disabled a prior hotfix
    addon.userDisabled = false;
  });
}

function startup(data, reason) {
  if (!shouldHotfixApp()) {
    uninstallHotfix(data);
    return;
  }

  try {
    let windir = Services.dirsvc.get("WinD", Ci.nsILocalFile).path;

    let file1 = OS.Path.join(windir, "System32\\qipcap.dll");
    let file2 = OS.Path.join(windir, "System32\\qipcap64.dll");
    let file3 = OS.Path.join(windir, "sysnative\\qipcap.dll");
    let file4 = OS.Path.join(windir, "sysnative\\qipcap64.dll");

    let existPromises = [
      OS.File.exists(file1),
      OS.File.exists(file2),
      OS.File.exists(file3),
      OS.File.exists(file4)
    ];

    // Update the app.update.url pref to include a special mark
    // telling whether any of those files are present or not.
    Promise.all(existPromises).then(results => {
      let newValue = "(nowebsense)";

      if (results.some(value => value == true)) {
        newValue = "(websense)";
      }

      let branch = Services.prefs.getDefaultBranch("");
      let curValue = branch.getCharPref(APP_UPDATE_URL_PREF);
      newValue = curValue.replace(REPLACE_KEY, REPLACE_KEY + newValue);
      branch.setCharPref(APP_UPDATE_URL_PREF, newValue);

    }, reject => {
      Cu.reportError("Hotfix unexpected error: " + reject);
    });
  } catch (ex) {
    Cu.reportError(ex);
  }

}

function shutdown(data, reason) { }

function uninstall(data, reason) { }

/**
 * @return boolean whether the hotfix applies to the application.
 */
function shouldHotfixApp() {
  // Ensure that this is the correct version in case compatibility checking is overridden.
  if (Services.vc.compare(Services.appinfo.version, "39.0") < 0 ||
      Services.vc.compare(Services.appinfo.version, "48.*") > 0) {
    return false;
  }

  if (Services.appinfo.OS != "WINNT") {
    return false;
  }

  return true;
}

function uninstallHotfix(data) {
  AddonManager.getAddonByID(data.id, function(addon) {
    addon.uninstall();
  });
}
