/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
"use strict";

/* exported startup, shutdown, install, uninstall */

Components.utils.import("resource://gre/modules/Services.jsm");

function startup() {
}

function shutdown() {
}

function install() {
  // For 45 - 48, just installing this new add-on version is enough to disable
  // Loop as it overrides the shipped system add-on.
  // For 44, we need to disable the pref, as Loop was built-in to Firefox (not
  // an add-on).
  if (Services.prefs.getBoolPref("loop.enabled") &&
      Services.vc.compare(Services.appinfo.version, "45.0a1") < 0) {
    Services.prefs.setBoolPref("loop.enabled", false);
  }
}

function uninstall() {}
